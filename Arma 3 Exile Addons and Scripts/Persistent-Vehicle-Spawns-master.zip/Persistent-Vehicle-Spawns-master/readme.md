#Installation

Merge the conents of initServer.sqf with your own Exile."MapName"\initServer.sqf
Drop the Persistent folder inside your Exile."MapName" folder
Configure "Spawn_vehicles.sqf" inside your the persistent folder

Strongly suggest you use either this script OR Exiles standard world vehicle spawn system, not both as your players will be confused.
