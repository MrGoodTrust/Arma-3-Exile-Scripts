Before you start, all credits go to Shix07 for making this script.

# Installation Instructions

All the files in this download are placed into the folder where they should be, 
so this will make it easy for you to just copy/paste.

If you make changes to the destination of the folders, make sure you call them
correctly or you will end up with lots of issues.
