###Oct5.2016
**[ADDED]** possibility to add structured text to the title of each menu section ( @koutamarto ) <br />
**[CHANGED]** openAtLogin from yes to no <br />
**[TWEAKED]** all code syntax <br />
<br />

###August 8, 2016
**[ADDED]** option to enable/disable the automatic opening of the menu when player has finished loading in <br />
<br />

###June 11, 2016
**[ADDED]** option to enable/disable action menu item <br />
**[NEW]** menu now closes in a fancy way <br />
**[TWEAKED]** menu opening speed <br />
<br />

###May 4, 2016
**[CHANGED]** font size of IP:PORT to accommodate for larger IP addresses <br />
**[FIXED]** incorrect default IP address length <br />
**[FIXED]** ServerInfoMenu action gone after respawn <br />
<br />

###April 28, 2016
**[ADDED]** config setting for choosing an action to use for opening menu with keyboard <br />
**[CHANGED]** action menu item. Is now as low as possible in the action menu <br />
**[CHANGED]** menu items configuration. the classes can be named anything, the title of menu items are set by the menuName setting. <br />
**[NEW]** action menu now has an icon. <br />
<br />

###April 24, 2016
**[FIXED]** Error: "Variable _this does not support serialization" <br />
**[FIXED]** Error: "Custom font not installed, replacing with default ArmA 3 font" <br />
<br />
