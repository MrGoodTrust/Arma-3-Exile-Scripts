##ArmA3_exile_ServerInfoMenu
###Advanced Server Info Menu for ArmA 3 Exile Mod
<br />
######HOW TO DOWNLOAD
Click the "Download ZIP" button<br />
######INSTALLATION GUIDE
```
Exile.MapName\init.sqf (contents) >> MPmissions\Exile.*nameOfMap*\init.sqf
Exile.MapName\description.ext (contents) >> MPmissions\Exile.*nameOfMap*\description.ext
Exile.MapName\scarCODE >> MPmissions\Exile.*nameOfMap*\
```
The menu's IDD is 7770. In case you use some sort of antihack that has IDD whitelist.<br />
######CONFIGURATION GUIDE
Have a look in:
```
Exile.MapName\scarCODE\ServerInfoMenu\hpp\CfgServerInfoMenu.hpp
```
