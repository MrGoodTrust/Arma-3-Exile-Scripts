# Monkeys-Welcome-Toasts
Welcome messages for Exile in the form of Exile Toasts

/*		
	Script name: Monkey's Welcome Toasts
	Author: [GADD] Monkeynutz
	Description: Fully customizable welcome messages.
	Liscence: You are free to edit the script as you please. Steal it from my mission file/download it or what ever,
	just edit what you want and if you have questions, come and ask me on TeamSpeak: ts3.gamingatdeathsdoor.com or 
	www.gamingatdeathsdoor.com on my forums. Don't distribute it to other people under your own name. Send them to
	my download links on the Exile Forums.
*/

Join my Discord at http://discord.gamingatdeathsdoor.com if you have any problems.

1. If you do not have one already, copy the entire custom folder to your Exile.mapname folder, if you do, drag MWT into the custom folder etc.
2. Copy code from the initPlayerLocal.sqf into yours (Must be positioned like mine.)
3. Cope code from config.cpp into yours too. (Thanks Kuplion for the help on the override)
4. Edit welcometoasts.sqf to suit your server. It's pretty straight forward so follow it's layout.
5. Re-pack your PBO and launch the server to admire your new messages!

MAKE SURE IF YOU ADD/REMOVE MESSAGES, THEY FOLLOW THE SAME FORMAT AS OTHER MESSAGES. THERE ARE MESSAGES FOR USE OF EXAD STUFF AND BRAMA RECIPES RIGHT NOW.
COMMENT OUT THE LINES YOU DONT WANT AND PLEASE MAKE SURE THAT YOU READ THE MESSAGE FORMATS AND TEXT SO YOU KNOW WHAT YOU ARE COMMENTING OUT BEFORE YOU DO
OR YOU MIGHT BREAK THE SCRIPT. I HAVE EVEN GONE AS FAR AS SEPERATING EACH MESSAGE SO ITS EASY FOR YOU! AND MAKE SURE THE LAST MESSAGE DOES NOT HAVE "sleep n";
AT THE END OR MORE STUFF MIGHT BREAK :P

OTHER THAN THAT! ENJOY AND THANKS FOR THE DOWNLOAD!
