Лицензия:
	Собственником является и остается Alexis aka FairyTale
	Discord: FairyTale#5571
	VK: https://vk.com/juba_johnson
	E-Mail: a3atlaslife@gmail.com
	
	You are not allowed to post / publish / use / modify files without my written permission!
Installation:
	
In the database, run the atlas_virtualgarage.sql file
	Place the contents of the exile_extDB * .ini file at the very bottom of the exile.ini file
		* - extDB version
		
	
File Atlas_VirtualGaragePublic.pbo put in @ExileServer\addons folder
	
	
In the mission file in description.ext add the line #include "VirtualGarageP\dialog.h"
	
	
In class CfgExileCustomCode enter *
		ExileServer_object_player_createBambi = "\Atlas_VirtualGaragePublic\exile_server\ExileServer_object_player_createBambi.sqf"
		ExileServer_object_player_database_load = "\Atlas_VirtualGaragePublic\exile_server\ExileServer_object_player_database_load.sqf"
		
	if these functions are present, it is necessary to combine the changes
		
	 Put VirtualGarageP folder in the root of the mission!
	
	Combine the CfgNetworkMessages.h file with the existing CfgNetworkMessages class, if it does not exist, add the line #include "VirtualGarageP\CfgNetworkMessages.h" in the description.ext
	
	
Inside the CfgInteractionMenus class add #include "VirtualGarageP\CfgInteractionMenus.h"
	
Радоваться!

In case of any problems with the script, please contact me personally (Alexis)