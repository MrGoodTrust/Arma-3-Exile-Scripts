class CfgExileCustomCode 
{
	//Kill Messages
	ExileServer_object_player_event_onMpKilled = "overwrites\ExileServer_object_player_event_onMpKilled.sqf";
};