# R3F-Crate-Selling
Crate Selling scripts for R3F and Exile. Complete with infiSTAR logging functionality.
Join my Discord at http://discord.gamingatdeathsdoor.com if you have any problems.

Original Script found here: http://www.exilemod.com/topic/19038-sell-crates-at-wastedump-r3f-required/
My version, adds the pop tabs to the player, updates the player's respect and deletes the crate from the world.
Deleting the crate prevents other players from taking the money.

## Install Instructions

Replace the mpmission.mapname.pbo\R3F_LOG\objet_deplacable\relacher.sqf with the one proveded here.

Pack the gadd_extras folder into a PBO and drop it into your @ExileServer\addons folder.

If you use infiSTAR set _useInfiSTAR to true in relacher.sqf.

Configure everything else how you want it. Configurable things have comments next to them. DO NOT EDIT ANYTHING ELSE UNLESS YOU KNOW
WHAT YOU ARE DOING!!!!!!
