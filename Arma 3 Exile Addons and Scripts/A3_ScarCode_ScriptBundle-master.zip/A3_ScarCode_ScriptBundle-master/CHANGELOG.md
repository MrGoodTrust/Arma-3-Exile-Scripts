##SCSB CHANGELOG

#### 5th,July,2015: introCamera update
**[CHANGED]** Font styling and position of text. Read and re-apply your custom config.sqf settings <br />

#### 4th,July,2015: fixed cfgFunctions mixup
SC_fnc_handleKilled was placed under introCredits instead of PVE.

#### 7th of July 2015: SCMP v0.2
**[ADDED]** New function that handles opening menu from dropdown box <br />
**[ADDED]** Simple Ammo Repacker to available menus
**[CHANGED]** Instead of buttons, combobox is now used to open menus <br />

#### S.A.R. `v0.0422`
Overall improvements :)

#### S.A.R. `v0.041b BETA`
**[FIXED]** Late response if mag in weapon<br />
**[FIXED]** Slow loading<br />
**[NEW]** Layout. Darker colors