/*
    Master UI Resource File
*/

class RscTitles
{
    // Statusbar
	#include "dialogs\ExileStatusbar.hpp"
};