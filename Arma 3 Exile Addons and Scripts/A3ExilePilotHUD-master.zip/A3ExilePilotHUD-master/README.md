# A3ExilePilotHUD
Arma 3 Exile HUD for the pilot, displays the ammo count, flare count, and jet engine throttle percentage.

## Installation
### Exile
Copy the custom folder into your Exile.MapName folder.  
Merge or copy the description.ext  
Merge or copy the initPlayerLocal.sqf  

  
## Settings
The display is using the arma 3 structured text control, although not recommended you can change how the information is displayed inside the custom/PilotHUD/init.sqf file.  
look for ``` _string = ""; ``` this is where the text is created and later added to the control.


## License
Noncommercial - You may not use this material for any commercial purposes. 
Feel free to Modify and Distribute.

