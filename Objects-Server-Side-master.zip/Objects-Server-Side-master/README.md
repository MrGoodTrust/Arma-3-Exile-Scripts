# Objects-Server-Side
Add you stuff wit Exile Mod 3DEN Plugin
Custom Objects/Buildings(m3editor) server addon .
Download TKO_Objects go to TKO_Objects\mapcontent\trader.sqf open and delete the stuff its from Tanoa only for exempel!!
Download @m3e_3den includet Exile Plugin , loaded as Mod with Tanoa Map and @Exile as exempel , set you Stuff on the map , export on editor on top see Exile, as initServer , coppy the lines and paste on TKO_Objects\mapcontent\trader.sqf.
Pack as PBO , put on @Exile Server Addon , start Server

