name = "M3Editor - 3DEN";
author = "maca134";
actionName = "Website";
action = "https://github.com/maca134/armaext";